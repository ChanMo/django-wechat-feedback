default_app_config = 'feedback.apps.FeedbackConfig'
