#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class FeedbackConfig(AppConfig):
    name = u'feedback'
    verbose_name = u'反馈'
